package com.adiaz.data.api;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

/**
 * Created by toni on 23/07/2017.
 */
public class FirstMockitoTest {

	@Test
	public void test() {
		assertTrue(true);
	}
}
